import ChatLayout from "@/components/sections/chat/chat-layout";

export default function Home() {
  return <ChatLayout />;
}
